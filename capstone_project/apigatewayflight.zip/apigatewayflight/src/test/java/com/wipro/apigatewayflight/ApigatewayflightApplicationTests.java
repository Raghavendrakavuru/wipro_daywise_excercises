package com.wipro.apigatewayflight;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApigatewayflightApplicationTests {

	@Test
	void contextLoads() {
	}

}
